  
<div id="page-content-wrapper">
  <form action="">
    <h1><?php echo $nama ?></h1>
  </form>
</div>